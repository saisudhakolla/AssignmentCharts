import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

export class Bar{
  labels: string;
  datasets: string;
}

@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.css']
})
export class BarComponent implements OnInit {

  public weekBars: Bar[] = [];
  public monthBars: Bar[] = [];
  public yearBars: Bar[] = [];
  Data : any

  private weekurl = 'http://localhost:8080/customer/week';
  private monthurl = 'http://localhost:8080/customer/month';
  private yearurl = 'http://localhost:8080/customer/year';

  constructor(private http: HttpClient) { }

  ngOnInit() {

    this.getWeekBars()
      .subscribe(data => {
      this.weekBars = data;
      console.log("WeekData : ", data)
      

    this.getMonthBars()
      .subscribe(data => {
      this.monthBars = data;
      console.log("MonthData : ", data)

    this.getYearBars()
      .subscribe(data => {
      this.yearBars = data;
      console.log("Yeardata:", data)

    this.Data = {
              labels: ['Week', 'Month', 'Year'],
              datasets: [
                {
                  label: 'Customers',
                   backgroundColor: '#42A5F5',
                  borderColor: '#7CB342',
                  data: [this.weekBars.length, this.monthBars.length, this.yearBars.length]
                }
              ]
            }
           

    },error => console.log(error));
    },error => console.log(error));           
    },error => console.log(error)); 
    
  }

  getWeekBars(): Observable<Bar[]>{
    return this.http.get<Bar[]>(`${this.weekurl}`) 
  }

  getMonthBars(): Observable<Bar[]>{
    return this.http.get<Bar[]>(`${this.monthurl}`) 
  }

  getYearBars(): Observable<Bar[]>{
    return this.http.get<Bar[]>(`${this.yearurl}`) 
  }

}
