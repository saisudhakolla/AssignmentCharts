import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

export class Pie{
  labels: string;
  datasets: string;
}

@Component({
  selector: 'app-pie',
  templateUrl: './pie.component.html',
  styleUrls: ['./pie.component.css']
})
export class PieComponent implements OnInit {

  public weekPies: Pie[] = [];
  public monthPies: Pie[] = [];
  public yearPies: Pie[] = [];
  Data : any

  private weekurl = 'http://localhost:8080/customer/week';
  private monthurl = 'http://localhost:8080/customer/month';
  private yearurl = 'http://localhost:8080/customer/year';

  constructor(private http: HttpClient) { }

  ngOnInit(){

    this.getWeekPies()
      .subscribe(data => {
      this.weekPies = data;
      console.log("WeekData : ", data)
      

    this.getMonthPies()
      .subscribe(data => {
      this.monthPies = data;
      console.log("MonthData : ", data)

    this.getYearPies()
      .subscribe(data => {
      this.yearPies = data;
      console.log("YearData:", data)

    this.Data = {
              labels: ['Week', 'Month', 'Year'],
              datasets: [
                {
                  label: 'Customers',
                  data: [this.weekPies.length, this.monthPies.length, this.yearPies.length],
                  backgroundColor: [
                    "#FF6384",
                    "#36A2EB",
                    "#F5DEB3"
                ],
                  hoverBackgroundColor: [
                    "#FF6384",
                    "#36A2EB",
                    "#FFCE56"
                ]
                }
              ]
            }
           

    },error => console.log(error));
    },error => console.log(error));           
    },error => console.log(error));

  }

  getWeekPies(): Observable<Pie[]>{
    return this.http.get<Pie[]>(`${this.weekurl}`) 
  }

  getMonthPies(): Observable<Pie[]>{
    return this.http.get<Pie[]>(`${this.monthurl}`) 
  }

  getYearPies(): Observable<Pie[]>{
    return this.http.get<Pie[]>(`${this.yearurl}`) 
  }

}
