import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

export class Line{
  labels: string;
  datasets: string;
}

@Component({
  selector: 'app-line',
  templateUrl: './line.component.html',
  styleUrls: ['./line.component.css']
})
export class LineComponent implements OnInit {

  public weekLines: Line[] = [];
  public monthLines: Line[] = [];
  public yearLines: Line[] = [];
  Data : any

  private weekurl = 'http://localhost:8080/customer/week';
  private monthurl = 'http://localhost:8080/customer/month';
  private yearurl = 'http://localhost:8080/customer/year';

  constructor(private http: HttpClient) { }

  ngOnInit() {

    this.getWeekLines()
      .subscribe(data => {
      this.weekLines = data;
      console.log("WeekData : ", data)
      

    this.getMonthLines()
      .subscribe(data => {
      this.monthLines = data;
      console.log("MonthData : ", data)

    this.getYearLines()
      .subscribe(data => {
      this.yearLines = data;
      console.log("YearData:", data)

    this.Data = {
              labels: ['Week', 'Month', 'Year'],
              datasets: [
                {
                  label: 'Customers',
                  fill: false,
                  borderColor: '#DB7093',
                  data: [this.weekLines.length, this.monthLines.length, this.yearLines.length]
                }
              ]
            }
           

    },error => console.log(error));
    },error => console.log(error));           
    },error => console.log(error));

  }

  getWeekLines(): Observable<Line[]>{
    return this.http.get<Line[]>(`${this.weekurl}`) 
  }

  getMonthLines(): Observable<Line[]>{
    return this.http.get<Line[]>(`${this.monthurl}`) 
  }

  getYearLines(): Observable<Line[]>{
    return this.http.get<Line[]>(`${this.yearurl}`) 
  }

}
